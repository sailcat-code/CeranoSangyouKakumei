![烛台](block:betterwithmods:candle_holder)

烛台是一个向上堆叠的方块，许多东西都可以放在上面。