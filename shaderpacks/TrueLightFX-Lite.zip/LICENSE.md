
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

TrueLightFX Shader – License Agreement

Copyright © OGCRAFTNET STUDIOS, 2023-2025

This shader (TrueLightFX) is the intellectual property of OGCRAFTNET STUDIOS. By downloading, installing, or using this shader, you agree to the following terms:

    Personal Use Only
    This shader is licensed for personal, non-commercial use only. You may use it in your own Minecraft installation and personal videos or screenshots.

    Redistribution
    Redistribution of TrueLightFX, in original or modified form, is not allowed without explicit permission from the creator. This includes uploading the shader to other websites or file hosts.

    Modification
    You may modify the shader files for personal use. However, you may not distribute or share modified versions publicly.

    Commercial Use
    Use of TrueLightFX in commercial projects (e.g., monetized servers, YouTube videos, or modpacks) requires prior written permission from the creator.

    Credit
    If used in videos, screenshots, or public projects, crediting the shader as “TrueLightFX Shader by OGCRAFTNET STUDIOS” is appreciated.

    Liability
    The shader is provided “as is”, without warranty of any kind. The creator is not responsible for any damages, data loss, or performance issues caused by its use.



----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------